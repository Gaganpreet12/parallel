package usingcollection.bean;

public class BankBean {

	private String userName;
	private long accNumber;
	private int pinNumber;
	private String addRes;
	private String phoneNumber;
	private int balance;

	String trans = new String();
	
	public BankBean() {	
	}
	
	public BankBean(String userName, int accNumber, int pinNumber, String dob2, String addRes, String phoneNumber, int balance) {
		super();
	}
	
	public int getPin() {
		return pinNumber;
	}

	public void setPin(int pinNumber) {
		this.pinNumber = pinNumber;
	}


	public String getTrans() {
		return trans;
	}

	public void setTrans(String string) {
		trans = string;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getuserName() {
		return userName;
	}

	public void setuserName(String userName) {
		this.userName = userName;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public long setAccNumber(long accNumber) {
		return this.accNumber = accNumber;
	}

	public String getAddRes() {
		return addRes;
	}

	public void setAddRes(String addRes) {
		this.addRes = addRes;
	}
	
	@Override
	public String toString() {
		return "Account Details Name =" + userName + "\n Account Number =" + accNumber + "\n Pin =" + pinNumber + "\n add =" + addRes
				+ "\n Phone Number =" + phoneNumber + "\nBalance =" + balance;
	}

}
