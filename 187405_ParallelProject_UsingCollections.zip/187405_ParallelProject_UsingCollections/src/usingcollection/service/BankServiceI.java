package usingcollection.service;

import usingcollection.Exceptions.AccountAlreadyExistsException;
import usingcollection.Exceptions.AccountNotFoundException;
import usingcollection.Exceptions.LowBalanceException;

public interface BankServiceI {

	public boolean createAccount(String name, String add, long accNum, String phoneNum, int pin, int balance)
			throws AccountAlreadyExistsException;

	public int showBalance(long accNum) throws AccountNotFoundException;

	public int deposit(long accNum, int depositAmount) throws AccountNotFoundException;

	public int withdraw(long accNum, int withdrawAmount) throws AccountNotFoundException, LowBalanceException;

	public boolean transferfund(long accNum, long accNum1, int transferAmount)
			throws AccountNotFoundException, LowBalanceException;

	public boolean validateBalance(long accNum, int amount) throws LowBalanceException;

	public String setTrans(long accNum) throws AccountNotFoundException;

}
