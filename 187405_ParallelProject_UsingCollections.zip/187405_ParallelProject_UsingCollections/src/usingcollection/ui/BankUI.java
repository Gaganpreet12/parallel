package usingcollection.ui;

import java.util.Scanner;
import usingcollection.Exceptions.*;
import usingcollection.service.BankService;
import usingcollection.service.BankServiceI;

public class BankUI {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException {

		//declaring variables
		int withdrawAmt = 0, depositAmt = 0, transferAmt = 0;
		int pinNumber;
		long accNum, accNumNew;
		int amount = 0;
		int balance = 0;
		String flag = "yes";
		boolean result = false;

		BankServiceI service = new BankService();

		//To ask choice from users and perform operations accordingly
		while (flag.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// to create user account

			case 1:

				System.out.println("\nEnter your name:\n");
				String userName = sc.nextLine();
				userName += sc.nextLine();

				String regexUseruserName = "[A-Za-z\\s]+$";
				while (!userName.matches(regexUseruserName)) {

					System.out.println("Invalid Format Entered");
					System.out.println("\nEnter your name:\n");
					userName = sc.next();
				}

				System.out.println("Enter add results: ");
				String addRes = sc.next();
				addRes += sc.nextLine();

				while (!addRes.matches(regexUseruserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter add results: ");
					addRes = sc.nextLine();

				}

				System.out.println("Enter your phone number:");
				String phoneNumber = sc.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phoneNumber.matches(phone_format)) {
					while (phoneNumber.length() < 10 || phoneNumber.length() > 10) {

						System.out.println("Phone number must be of 10 digits!");
						System.out.println("Enter your phone number:");
						phoneNumber = sc.next();
					}
					System.out.println("Phone number should start from 6!");
					System.out.println("Enter your phone number:");
					phoneNumber = sc.next();
				}

				accNum = Long.parseLong(phoneNumber) - 10000;

				System.out.println("Enter the pin:\n");
				pinNumber = sc.nextInt();

				while (String.valueOf(pinNumber).length() < 4 || String.valueOf(pinNumber).length() > 4) {

					System.out.println("Pin number must be of 4 digits");
					System.out.println("Enter the pin:\n");
					pinNumber = sc.nextInt();
				}

				System.out.println("Enter Balance:\n");
				int balAmt = sc.nextInt();

				while (balAmt < 1000) {
					System.out.println("Minimum Balance in an account should be 1000");
					System.out.println("Enter Balance:\n");
					balAmt = sc.nextInt();

				}
				try {
					result = service.createAccount(userName, addRes, accNum, phoneNumber, pinNumber, balAmt);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully !!");
					System.out.println("Account Number is: " + accNum);

				} else {

					System.out.println("Account cannot be created.");
				}

				break;

			//to show account balance
			case 2:

				System.out.println("Enter account number to check balance:");
				accNum = sc.nextLong();

				try {
					balance = service.showBalance(accNum);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance present in your account is:" + balance);

				break;

			//To deposit amount

			case 3:

				System.out.println("Enter account number:");
				accNum = sc.nextLong();

				System.out.println("Enter the amount to be deposited:");
				depositAmt = sc.nextInt();

				try {
					amount = service.deposit(accNum, depositAmt);

					balance = service.showBalance(accNum);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited: " + depositAmt);
				System.out.println("Updated Balance: " + balance);

				break;

			// to withdraw money

			case 4:

				System.out.println("Enter account number:");
				accNum = sc.nextLong();

				System.out.println("Enter the amount to be withdrawn:");
				withdrawAmt = sc.nextInt();

				try {
					amount = service.withdraw(accNum, withdrawAmt);
					result = service.validateBalance(accNum, withdrawAmt);
					balance = service.showBalance(accNum);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdrawAmt);
				System.out.println("Updated Balance : " + balance);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter account number:");
				accNum = sc.nextLong();

				System.out.println("Enter account to which you want to transfer fund:");
				accNumNew = sc.nextLong();

				System.out.println("Enter the amount to be transferred:");
				transferAmt = sc.nextInt();

				try {
					result = service.validateBalance(accNum, transferAmt);
					result = service.transferfund(accNum, accNumNew, transferAmt);

					senders_balance = service.showBalance(accNum);
					recievers_balance = service.showBalance(accNumNew);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully!!");
				System.out.println("Updated balance for Account " + accNum + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accNumNew + " : " + recievers_balance);

				break;

			// to show transactions
			case 6:

				String s = null;
				System.out.println("Enter account number:");
				accNum = sc.nextLong();
				System.out.println("Enter the pin number:");
				pinNumber = sc.nextInt();
				try {
					s = service.setTrans(accNum);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				// to exit
			case 7:
				System.exit(0);
				flag = "no";
				break;
			default:
				System.out.println("Please Enter the choice between 1 - 7 ");
				menu();

			}
		}

	}

	// to display menu
	public static int menu() {

		System.out.println("\n------------Welcome to Capgemini Bank----------\n");
		System.out.println("Enter 1 : Create Account");
		System.out.println("Enter 2 : Show Balance");
		System.out.println("Enter 3 : Deposit");
		System.out.println("Enter 4 : Withdraw");
		System.out.println("Enter 5 : Transfer Fund");
		System.out.println("Enter 6 : Print Transcations");
		System.out.println("Enter 7 : Exit");

		System.out.println("Enter your Choice:");
		int choice = sc.nextInt();

		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Chice");
			System.out.println("Enter your Choice:");
			choice = sc.nextInt();
		}
		return choice;
	}

}
