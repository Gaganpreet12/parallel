package com.bank.dao;

import com.bank.entity.BankDetails;

public interface BankDAOInterface {
	public BankDetails getAccountById(int id);

	public void CreateAccount(BankDetails bankObj);

	public void ShowBalance(BankDetails bankObj);

	public void Deposit(BankDetails bankObj);
	
	public void Withdraw(BankDetails bankObj);
	
	public void PrintTransactions(int id);

	public  void commitTransaction();

	public void beginTransaction();

}
