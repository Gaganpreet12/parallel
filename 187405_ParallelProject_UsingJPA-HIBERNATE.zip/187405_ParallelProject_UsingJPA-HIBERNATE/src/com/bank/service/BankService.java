package com.bank.service;

import com.bank.dao.BankDAO;
import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;

public class BankService implements BankServiceInterface {
	BankDAO daoObj = new BankDAO();

	@Override

	public BankDetails getAccountById(int id) {
		BankDetails bank = daoObj.getAccountById(id);
		return bank;
	}

	@Override
	public void CreateAccount(BankDetails bank) {
		daoObj.beginTransaction();
		daoObj.CreateAccount(bank);
		daoObj.commitTransaction();
	}

	@Override
	public void ShowBalance(BankDetails bank) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Deposit(BankDetails bank) {
		daoObj.beginTransaction();
		daoObj.Deposit(bank);
		daoObj.commitTransaction();

	}

	@Override
	public void Withdraw(BankDetails bank) {
		daoObj.beginTransaction();
		daoObj.Withdraw(bank);
		daoObj.commitTransaction();
	}

	@Override
	public void PrintTransactions(int id) {
		daoObj.PrintTransactions(id);

	}

	@Override
	public void commitTransaction() {
		daoObj.commitTransaction();

	}

	@Override
	public void beginTransaction() {
		daoObj.beginTransaction();
	}

	public void addTransaction(TransactionDetails transObj) {

		daoObj.beginTransaction();
		daoObj.addTransaction(transObj);
		daoObj.commitTransaction();
	}

}
